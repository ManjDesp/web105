﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicProjects2
{
    internal static class Dictonary1
    {
        public static void CreateDictonary()
        {
            IDictionary<int, string> mydict1 = new Dictionary<int, string>();
            mydict1.Add(1, "One");
            mydict1.Add(2, "Two");
            mydict1.Add(3, "Three");
            mydict1.Add(4, "Four");
            mydict1.Add(5, "Five");

            foreach(KeyValuePair<int,string> kvp in mydict1)
            {
                Console.WriteLine("Key: {0}, Value: {1}",kvp.Key,kvp.Value);
            }
        }
        //creating a dictionary using collection-initializer syntax
        public static void CIDictonary()
        {
            var cities = new Dictionary<string, string>()
            {
                {"UK","London,Wales" },
                {"USA","NewYork,AngelCity" },
                {"India","Mumbai,Pune" }
            };

            foreach (var kvp in cities)
            {
                Console.WriteLine("Key: {0}, Value: {1}", kvp.Key, kvp.Value);
            }
        }
    }
}
