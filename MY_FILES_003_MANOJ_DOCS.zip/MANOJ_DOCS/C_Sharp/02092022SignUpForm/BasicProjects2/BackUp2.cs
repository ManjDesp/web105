﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicProjects2
{
    internal class BackUp2
    {
        /*
         *   //Console.WriteLine("Hello");
        /*
        MethodOverload mo = new MethodOverload();
        mo.add(2,3);
        mo.add(2,2,2);
        */
        //MethodOverloadTest test1 = new MethodOverloadTest();
        //MethodOverloadTest.testOverLoad();

        //MethodOverride.testMethodOverride();
        //InterfaceDemo.interfaceDemo();
        //AbstractClassDemo.testAbstractClass();
        /*
         * 
         */
        //AbstractClassDemo.testAbstractClass();
        //RayList.ArrayListOp();
        //CWCDemo demo = new CWCDemo();
        //CWCDemo.csgAssignment();

        /*
        Dictonary1.CreateDictonary();
        Console.WriteLine("---------------------------------");
        Dictonary1.CIDictonary();
        Console.WriteLine("---------------------------------");
        */

        //Exception1.ExceptionDemo1();
        //Exception1.ExceptionDemo2();
        //Exception1.ExceptionDemo3();
        //Exception1.ExceptionDemo4();
        //Exception1.ExceptionDemo5();
        //Exception1.ExceptionDemo6();
        //Exception1.ExceptionDemo7();
        /*
        CustomException1 newStudent = null;
        try
        {
            newStudent = new CustomException1();
            newStudent.StudentName = "James002";

            ValidateStudent(newStudent);
        }
        catch(InvalidStudentNameException ex)
        {
            Console.WriteLine(ex.Message);  
        }
        Console.ReadKey();
    }

    private static void ValidateStudent(CustomException1 newStudent)
    {
        Regex regex = new Regex("^[a-zA-Z]+$");
        if(regex.IsMatch(newStudent.StudentName))
        throw new InvalidStudentNameException(newStudent.StudentName);
    }
        */
        //three integer variables are defined
        /*
            int a, b, c;
            Console.WriteLine("Please enter two numbers and type of the numbers must be integer:");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            try
            {
                //checking if the divisor is an odd number or an even number
                if (b % 2 > 0)
                {
                    //exception is thrown if the divisor is an odd number
                    throw new OddNumException();
                }
                c = a / b;
                Console.WriteLine(c);
            }
            catch (OddNumException two)
            {
                Console.WriteLine(two.Message);
            }
            Console.WriteLine("The program ends here");
            Console.ReadKey();
        */
        // CWG1Demo.csgAssignment();
        /*
        Dictonary1.CreateDictonary();
        Console.WriteLine("---------------------------------");
        Dictonary1.CIDictonary();
        Console.WriteLine("---------------------------------");
        */
        // InsufficientBalance insbal =new InsufficientBalance();
        //insbal.AddDeposit();
        //AccountDemo.testAccount();
    }
}
