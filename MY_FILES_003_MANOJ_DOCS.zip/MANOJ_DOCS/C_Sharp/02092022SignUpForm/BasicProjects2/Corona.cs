﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BasicCsharp
{
    internal class Corona
    {
        public int code;
        public string name;
        public int active;
        public int recovered;
        public int death;
        public int total;
        public Corona(int code, string name, int active, int recovered, int death, int total)
        {
            this.code = code;
            this.name = name;
            this.active = active;
            this.recovered = recovered;
            this.death = death;
            this.total = total;
        }
        public string info()
        {
            return $"Country Code : {code}\n State Name : {name} \nActive Case : {active}\n Recovered Case: {recovered} \nDeath Case: {death} \nTotal Case: {total}\n";
        }
    }
    internal class CoronaDashBoard
    {

       /* public List<Corona> coronas =new List<Corona>(10);

        coronas.
       */

        public List<Corona> coronaList = new List<Corona>() {
                new Corona(1, "Maharastra", 10000, 2000, 50, 30050),
                new Corona(2, "Gujarat", 8000, 2000, 10, 10010),
                new Corona(3, "Tamil Nadu", 6000, 1500, 15, 7515),
                new Corona(4, "Karnataka", 5000, 2000, 25, 7025),
                new Corona(5, "Goa", 2000, 1000, 5, 3500)
          };
        public void listCoronaData()
        {
            foreach (var list in coronaList)
            {
                Console.WriteLine(list.info());
            }
        }
        public void updateCoronaData()
        {
            int recovered = 0;
            int total = 0;
            foreach (var list in coronaList)
            {
                if (list.name.Equals("Karnataka"))
                {
                    recovered = list.recovered + 2;
                    total = list.total + 2;
                    break;
                }
            }
            Console.WriteLine($"After Updation of Karnataka recovered cases: " +
                              $"{recovered} and Total: {total}\n");

        }
        public void deleteCorona()
        {
            int deletedIndex = -1;
            foreach (var list in coronaList)
            {
                if (list.name.Equals("Gujarat"))
                {
                   deletedIndex = coronaList.IndexOf(list);
                    break;
                }
            }
            coronaList.RemoveAt(deletedIndex);
            Console.WriteLine("After Delete Gujarat State  Data list :\n");

            foreach (var list in coronaList)
            {
                Console.WriteLine(list.info());

            }
        }
        public void topstate()
        {
            int c = -1;
            int maxd = -1;
            foreach (var list in coronaList)
            {
                if (list.death > maxd)
                {
                    c = list.death;
                    maxd = list.death;
                }
            }
            foreach (var list in coronaList)
            {
                if (c == list.code)
                {
                    Console.WriteLine($"Top State in Death Rate {list.name} And Data Are \n {list.info}");
                }
            }
        }

    }
    internal class CoronaTest
    {
        public static void testCorona()
        {
            CoronaDashBoard c1 = new CoronaDashBoard();
            c1.listCoronaData();
            c1.updateCoronaData();
            c1.deleteCorona();
            c1.topstate();
        }
    }
}