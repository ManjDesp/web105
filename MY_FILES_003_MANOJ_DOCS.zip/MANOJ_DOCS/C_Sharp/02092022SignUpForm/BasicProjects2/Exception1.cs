﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicProjects2
{
    internal static class Exception1
    {
        public static void ExceptionDemo1()
        {
            Console.WriteLine("Enter a number: ");

            var num = int.Parse(Console.ReadLine());

            Console.WriteLine($"Squre of {num} is {num * num}");
        }

        public static void ExceptionDemo2()
        {
            try
            {
                Console.WriteLine("Enter a number: ");

                var num = int.Parse(Console.ReadLine());

                Console.WriteLine($"Squre of {num} is {num * num}");
            }
            catch
            {
                Console.WriteLine("Error Occured");
            }
            finally
            {
                Console.WriteLine("Retry with different number");
            }
        }
        public static void ExceptionDemo3()
        {
            try
            {
                Console.WriteLine("Enter a number: ");

                var num = int.Parse(Console.ReadLine());

                Console.WriteLine($"Squre of {num} is {num * num}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Info: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Retry with different number");
            }
        }
        public static void ExceptionDemo4()
        {
            try
            {
                Console.Write("Please enter a number : ");

                int num = int.Parse(Console.ReadLine());

                int result = 100 / num;

                Console.WriteLine("100 / {0} = {1}", num, result);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Cannot divide by zero. Please try again.");
            }

            catch (FormatException ex)
            {
                Console.WriteLine("Please Enter Something");
            }

        }
        /*
        public static void  ExceptionDemo5()
        {
            FileInfo file = null;

            try
            {
                Console.Write("Enter a file name to write: ");
                string fileName = Console.ReadLine();
                file = new FileInfo(fileName);
                file.AppendText("Hello World!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occurred: {0}", ex.Message);
            }
            finally
            {
                // clean up file object here;
                file = null;
            }
        */
        public static void ExceptionDemo6()
        {
            var divider = 0;

            try
            {
                var result = 100 / divider;
            }
            catch
            {
                Console.WriteLine("Outer catch");
            }
        }
        public static void ExceptionDemo7()
        {
            int num = 10;

            try
            {
                int result = 100 / num;
                if (result == 10)
                    throw new DivideByZeroException("OK But not Acceptable in this time");
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}