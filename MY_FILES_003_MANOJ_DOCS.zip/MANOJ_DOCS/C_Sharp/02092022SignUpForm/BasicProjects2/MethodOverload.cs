﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicProjects2
{
    internal class MetOverload
    {
        public void add(int a,int b)
        {
            int res = a + b;    
            Console.WriteLine("The Result is: "+res);
        }
        public void add(double a, double b, double c)
        {
            double res = a + b + c;
            Console.WriteLine("The Result is: " + res);
        }
    }
}
