﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicProjects2
{
    internal class RayList
    {
        public static void ArrayListOp()
        {
            Console.WriteLine("1 : Click to see the elements added\n");
            Console.WriteLine("2 : Click to see elements added using object initializer syntax\n");
            Console.WriteLine("3 : Click to see elements added to arraylist in array , arraylist or queque\n");
            Console.WriteLine("4 : Click to see of Accessing ArrayList\n");
            Console.WriteLine("5 : Click to see of Iterating ArrayList\n");
            Console.WriteLine("6 : Click to see the Insertion Operation in ArrayList using Insert()\n");
            Console.WriteLine("7 : Click to see the Insertion Operation in ArrayList using InsertRange()\n");
            Console.WriteLine("8 : Click to see the Remove Operation in ArrayList using Remove()\n");
            Console.WriteLine("9 : Click to see the Remove Operation in ArrayList using RemoveAt()\n");
            Console.WriteLine("10 :Click to see the Remove Operation in ArrayList using RemoveRange()\n");
            Console.WriteLine("11 :Click to see the Contain Operation\n");
            Console.WriteLine("===============================================");
            Console.Write("Select The Number to see the arraylist operation : ");
            int num = Convert.ToInt32( Console.ReadLine());
            switch (num)
            {
                case 1:
                    ArrayList arrayList = new ArrayList();
                    arrayList.Add(1);
                    arrayList.Add(2);
                    arrayList.Add(3);
                    arrayList.Add(4);
                    arrayList.Add(5);
                    for (int i = 0; i < arrayList.Count; i++)
                        Console.WriteLine("The item added is : " + arrayList[i]);
                    break;

                case 2:
                    var arlist2 = new ArrayList()
                    {
                        2, "Steve", true, 4.5, null
                    };
                    Console.WriteLine("ArrayList 1 Elements are : ");
                    for (int i = 0; i < arlist2.Count; i++)
                    {
                        Console.WriteLine("The item displayed is: " + arlist2[i]);
                    }
                    break;
                case 3:
                    var arlist3 = new ArrayList();

                    var arlist4 = new ArrayList()
                            {
                                1, "Bill", true, 4.5, null
                            };

                    int[] arr = { 100, 200, 300, 400 };

                    Queue myQ = new Queue();
                    myQ.Enqueue("Hello");
                    myQ.Enqueue("World");

                    arlist3.AddRange(arlist4);
                    arlist3.AddRange(arr);
                    arlist3.AddRange(myQ);

                    Console.WriteLine("ArrayList Elements are: ");

                    for (int i = 0; i < arlist3.Count; i++)
                        Console.Write("The Items added to the element are: " + arlist3[i] + "\n");
                    break;

                case 4:
                    var arlist1 = new ArrayList()
                {
                    1,"Bill",300,4.5f
                };
                    //Access individual item using indexer
                    int firstelement = (int)arlist1[0]; //returns 1
                    Console.WriteLine("The value of First  Element is: " + firstelement);
                    string secondelement = (string)arlist1[1];
                    Console.WriteLine("The value of Second Element is: " + secondelement);

                    //using var keyword without explicit casting
                    var firstElement = arlist1[0]; //returns 1
                    var secondElement = arlist1[1]; //returns "Bill"
                                                    //var fifthElement = arlist[5]; //Error: Index out of range

                    //update elements
                    arlist1[0] = "Steve";
                    arlist1[1] = 100;
                    // arlist1[5] = 500; //Error: Index out of range
                    Console.WriteLine("The Updated element of index 0 is: " + arlist1[0]);
                    Console.WriteLine("The Updated element of index 1 is: " + arlist1[1]);
                    //Console.WriteLine("The Updated element of index 5 is: "+arlist1[0]);
                    break;

                case 5:
                    ArrayList arlist = new ArrayList()
                        {
                            1,
                            "Bill",
                            300,
                            4.5F
                        };
                    Console.WriteLine("Using with foreach loop:This is the Result :\n");
                    foreach (var item in arlist)
                        Console.WriteLine(item + ", "); //output: 1, Bill, 300, 4.5,
                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("Using with for loop:This is the Result :\n");
                    for (int i = 0; i < arlist.Count; i++)
                        Console.WriteLine(arlist[i] + ", "); //output: 1, Bill, 300, 4.5, 
                    break;

                case 6:
                    ArrayList arlist5 = new ArrayList()
                {
                    1,
                    "Bill",
                    300,
                    4.5f
                };
                    arlist5.Insert(4, "Mando");
                    foreach (var val in arlist5)
                        Console.WriteLine("The Array element is: " + val);
                    break;

                case 7:
                    ArrayList arlist6 = new ArrayList()
                {
                    1,
                    "Bill",
                    300,
                    4.5f
                };
                    arlist6.InsertRange(2, arlist6);
                    foreach (var val in arlist6)
                        Console.WriteLine("The Array element is: " + val);
                    break;

                case 8:
                    ArrayList arList8 = new ArrayList()
                {
                    1,
                    "Bill",
                    300,
                    4.5f,
                    1
                };
                    //Console.WriteLine("The element at index 4 is: "+arList[4]);
                    arList8.Remove(1); //Removes first occurance of 1
                    foreach (var item in arList8)
                        Console.WriteLine("The elements of the array is: "+item);
                    break;

                case 9:
                    ArrayList arList9 = new ArrayList()
                 {
                    1,
                    "Bill",
                    300,
                    4.5f,
                    1
                };
                    //Console.WriteLine("The element at index 2 is: "+arList[2]);
                    arList9.RemoveAt(2); //Removes at index 2
                    foreach (var item in arList9)
                        Console.WriteLine("The elements of the array is: " + item);
                    break;

                case 10:
                    ArrayList arList10 = new ArrayList()
                 {
                    1,
                    "Bill",
                    300,
                    4.5f,
                    1
                };
                    //Console.WriteLine("The element at index 2 is: "+arList[2]);
                    arList10.RemoveRange(0,2); //Removes at index 2
                    foreach (var item in arList10)
                        Console.WriteLine("The elements of the array is: " + item);
                    break;
                case 11:
                    ArrayList arList11 = new ArrayList()
                 {
                    1,
                    "Bill",
                    300,
                    4.5f,
                    1
                };
                    Console.WriteLine("Is 300 contains in arraylist: "     +arList11.Contains(300));
                    Console.WriteLine("Is Mumbai contains in arraylist: "  +arList11.Contains("Mumbai"));
                    break;
            }
        }
    }
}