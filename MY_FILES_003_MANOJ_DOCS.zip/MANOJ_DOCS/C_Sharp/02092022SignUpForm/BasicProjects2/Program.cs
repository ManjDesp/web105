﻿using BasicCsharp;
using BasicProjects2;
using BasicsCSharp;
using ExceptionHandling;
using System.Text.RegularExpressions;

internal class Program
{
    public static void Main(string[] args)
    {
        CoronaTest.testCorona();
    }
}
