﻿using System;
//a namespace called exception handling is defined
namespace ExceptionHandling
{
    //The custom exception class called odd num exception class is created by inheriting the exception class
    public class OddNumException : Exception
    {
        //The property message is being overridden here
        public override string Message
        {
            get
            {
                return "There cannot be an odd divisor";
            }
        }
    }
    //a class called check is defined
}