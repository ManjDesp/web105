﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicCSharp
{
    internal class Operators
    {
        public static void Welcome()
        {
            Console.WriteLine("Hello User.Welcome to my World");
        }
        public static void Arthimetic()
        {
            int a = 4;
            int b = 2;
            int res = a + b;
            Console.WriteLine(res);
        }

        public void greet()
        {
            Console.WriteLine("greet");
        }

        public void whileloop()
        {
            int start = 2;
            int end = 20;
            while (start <= end)
            {
                Console.WriteLine("Speak");
            }
        }
        public void whileloop_break()
        {
            int start = 2;
            int end = 20;
            while(start <= end)
            {
                Console.WriteLine("Speak");
                break;
            }
        }
        //-----------------Assignment 01-------------------------------------------
        public void UserInput()
        {
            Console.WriteLine("Enter the Message :");
            string usercall = Console.ReadLine();
            Console.WriteLine("The Imported Message is :\n"+usercall);
        }
        public void SimpleInterest()
        {
            Console.Write("Enter the Principal :");
            int Principal = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the Time :");
            float time = (float)Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the Rate Of Interest :");
            float interest = (float)Convert.ToDouble(Console.ReadLine());
            int Si = (int)((Principal * time * interest) / 100);
            Console.WriteLine("The Simple Interset is :"+Si);
        }
        public void Multiply()
        {
            int num,i;
            Console.Write("Enter The Number :");
            num = Convert.ToInt32(Console.ReadLine());
            for( i = 1;i<= 10; i++){
                Console.WriteLine(num + " X " +i + " = " + num * i);
            }
        }
        public void MilesToKms()
        {
            float miles;
            double kms= 1.609344;
            Console.Write("Enter The Number to convert from Miles to Kilometeres :");
            miles = Convert.ToSingle(Console.ReadLine());
            double conres = miles * kms;
            Console.WriteLine("The Result is : " + conres + "kms");
        }

        public void CurConvert()
        {
            double usd, cons = 79.889012;
            Console.Write("Enter the Currency to Convert :");
            usd = Convert.ToDouble(Console.ReadLine());
            double res = usd * cons;
            Console.WriteLine("The Result is : " + res + " INR");
        }
        //-----------------Assignment 01-------------------------------------------
    }
}
