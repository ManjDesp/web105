﻿using BasicCSharp;
using System;
using System.Security.Principal;

namespace BasicCSharp
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            // Accounts acc = new Accounts("STR0001","MANOJ","md@gmail.com",654345665,0);
            //acc.welcome();
            Accounts2 ac = new Accounts2("Manoj", 0, 99039838, 1998, "md@gmail.com");
            do
            {
                Console.WriteLine("select the operation to perform:");
                Console.WriteLine("Enter 1 to perform deposit:");
                Console.WriteLine("Enter 2 to perform withdraw:");
                Console.WriteLine("Enter 3 to check balance:");
                Console.WriteLine("Enter 4 to exit:");
                int i = Convert.ToInt32(Console.ReadLine());
                switch (i)
                {
                    case 1:
                        ac.deposit();
                        break;
                    case 2:
                        ac.withdraw();
                        break;
                    case 3:
                        ac.getbalance();
                        break;
                    case 4: return;

                    default:
                        Console.WriteLine("Please enter a valid input");
                        break;
                }
            } while (true);
        }
    }
}  