﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace BasicCSharp
{
    internal class Accounts
    {
        public string acc_no;
        public string acc_name;
        public string acc_email;
        public long acc_mob;
        public long acc_bal;
        public Accounts(string acc_no,string acc_name,string acc_email,long acc_mob,
                        long acc_bal=0)
        {
            this.acc_no = acc_no;
            this.acc_name =acc_name;
            this.acc_email =acc_email;
            this.acc_mob = acc_mob;
            this.acc_bal = acc_bal;
        }
        public void welcome()
        {
            Console.WriteLine("==============WELCOME TO THE HDFC BANK======================\n");
            Console.WriteLine("===============CHOOSE ANY ONE===============================\n");
            Console.WriteLine("1:Account Balance");
            Console.WriteLine("2:Account Deposit");
            Console.WriteLine("3:Account Withdrawl");
            Console.WriteLine("=======================================================");
            Console.Write("Choose any one:");
            int option =Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("\nYou Choose this: "+option);
            Console.WriteLine("=======================================================");
            switch (option)
            {
                case 1:
                    void amt_bal()
                    {
                        balanceCheck();
                    }
                    amt_bal();
                    welcome();
                    break;

                case 2:
                    void amt_depo()
                    {
                        balanceCheck();
                        Console.Write("Enter the Amount to be deposited: ");
                        long depo = Convert.ToInt64(Console.ReadLine());
                        Console.WriteLine("=======================================================");
                        Console.WriteLine("The Amount deposited is : " + depo);
                        Console.WriteLine("=======================================================");
                        long amtres = this.acc_bal + depo;
                        this.acc_bal = amtres;
                        Console.WriteLine("Your Current Balance is : " + this.acc_bal);
                    }
                    amt_depo();
                    break;

                case 3:
                    void amt_with()
                    {
                        balanceCheck();
                        Console.Write("Enter the Amount to be withdrawed: ");
                        long wito = Convert.ToInt64(Console.ReadLine());
                        Console.WriteLine("=======================================================");
                        Console.WriteLine("The Amount withdrawed is : " + wito);
                        Console.WriteLine("=======================================================");
                        long witres = this.acc_bal - wito;
                        this.acc_bal = witres;
                        Console.WriteLine("Your Current Balance is : " + this.acc_bal);
                    }
                    amt_with();
                    break;

                default:
                    Console.WriteLine("Please Choose Number Again");
                    welcome();
                    break;
            }
        }

        private void balanceCheck()
        {
            Console.WriteLine("Your Current Balance is :" + this.acc_bal +"\n");
        }
    }
}
