﻿using BasicCSharp;
using System;

namespace BasicCSharp
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            MethodOverloading mo = new MethodOverloading();
            mo.add(2, 3);
        }
    }
}  