﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicCSharp
{
    internal class MethodOverloading
    {
        public void add(int a,int b)
        {
            int res =a+b;
            Console.WriteLine(res);
        }
        public void add(double a, double b,double c)
        {
            double res = a + b;
            Console.WriteLine(res);
        }
    }
}
