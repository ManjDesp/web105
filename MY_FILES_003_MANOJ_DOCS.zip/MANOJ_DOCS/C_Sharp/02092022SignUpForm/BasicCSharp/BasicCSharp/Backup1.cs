﻿/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicCSharp
{
    internal class Backup1
    {
        static void add()
        {
            int n1 = 100;
            int n2 = 200;
            int res = n1 + n2;
            Console.WriteLine(res);
        }

        static void dataTypes()
        {
            // Single line comment
            /*
             * Multi line comments
             * 
             */
           // int n1 = 10; // int datatype
           // long l1 = 10L; // long datatype
           // float f1 = 100.0F; // float datatype
           // double d1 = 1000.0000D; // double datatype
           // bool isActive = true; // boolean
           // char chr = 'A'; // character
           // string course = "C# programming";
           // Console.WriteLine(" int n1 " + n1);
           // Console.WriteLine(" long l1 " + l1);
           // Console.WriteLine($" f1 - {f1} : d1 - {d1}");
        //}
        /*
         * Implicit type conversion from lower size 
         * data type to higher size data type
         * 
         */

/*
        static void implicitTypeConversion()
        {
            Console.WriteLine("Implicit type conversion");
            int n1 = 10;
            double d1 = n1;
            Console.WriteLine($" int n1 {n1} : double d1 {d1}");
            float f1 = 1000.000F;
            double d2 = f1;
            Console.WriteLine($" float f1 {f1} : double d2 {d2}");
        }

        /*
         * Explicit Casting - converting from higher to
         * lower
         * 
         */
/*
        static void explicitTypeConversion()
        {
            Console.WriteLine("Explicit type conversion");
            long l1 = 1000000;
            int n1 = (int)l1;
            Console.WriteLine($" long l1 {l1} : int n1 {n1}");
        }

        static void Greeting()
        {
            Console.WriteLine("Enter Your Name");
            string name = Console.ReadLine();
            Console.WriteLine(name + "Welcome to C#");
            Console.WriteLine($"{name} - Welcome to C#");
        }


        //Add();
        //DataTypes();
        //ImplicitTypeConversion();
        //Operators op = new Operators();
        //Operators op1 = new Operators();
        //Operators.Arthimetic();
        //Operators.Welcome();

        //-----------****CALLING BY CREATING OBJECTS****------------------------
        //op.greet();
        //op.whileloop();
        //op.whileloop_break();
        //op.UserInput();

        //-----------****ASSIGNMENT 01---------------****------------------------
        /*
        op1.SimpleInterest();
        op1.Multiply();
        op1.MilesToKms();
        op1.CurConvert();
        */
        //-----------****ASSIGNMENT 01---------------****------------------------
        //ArrayDemo.arrays();
        //Console.WriteLine("Hello World");
        //Greeting();
        //SimpleInterest si = new SimpleInterest();
        //si.calculateinterest();

        /*
        Product product1= new Product();
        product1.code = 1;
        product1.name = "Mobile ";
        product1.desc = "10 inch 8 GB RAM 64 ";
        product1.supplier = "Nokia ";
        product1.price = 30000;

        string info = product1.info();
        Console.WriteLine(info);

        Product product2 = new Product();
        product2.code = 2;
        product2.name = "Laptop ";
        product2.desc = "15 inch 8 GB RAM 64 ";
        product2.supplier = "Lenovo ";
        product2.price = 60000;

        string info2 = product2.info();
        Console.WriteLine(info2);
        */

        /*
        Customer cust1 = new Customer(1, "Manoj", "a@gmail.com", "5566", "Bangalore");
        Console.WriteLine(cust1.info());
        cust1.country = "India";
        Console.WriteLine("Country : " + cust1.country);
        Console.WriteLine("Setting up Zip Code");
        cust1.zipcode = 56008;
        Console.WriteLine("Getting Zip Code");
        Console.WriteLine("ZipCode " + cust1.zipcode);
        */


        // Accounts acc = new Accounts("STR0001","MANOJ","md@gmail.com",654345665,0);
        //acc.welcome();
        /*
        Accounts2 ac = new Accounts2("Manoj", 0, 99039838, 1998, "md@gmail.com");
        do
        {
            Console.WriteLine("select the operation to perform:");
            Console.WriteLine("Enter 1 to perform deposit:");
            Console.WriteLine("Enter 2 to perform withdraw:");
            Console.WriteLine("Enter 3 to check balance:");
            Console.WriteLine("Enter 4 to exit:");
            int i = Convert.ToInt32(Console.ReadLine());
            switch (i)
            {
                case 1:
                    ac.deposit();
                    break;
                case 2:
                    ac.withdraw();
                    break;
                case 3:
                    ac.getbalance();
                    break;
                case 4: return;

                default:
                    Console.WriteLine("Please enter a valid input");
                    break;
            }
        } while (true);
        */


        /*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicCSharp
{
    internal class Accounts2
    {
        public string name;
        public double balance = 0;
        public long number;
        public int AccountNo;
        public string email;
        //constructor
        public Accounts2(string name, double balance, long number, int AccountNo, string email)
        {
            this.name = name;
            this.balance = balance;
            this.number = number;
            this.AccountNo = AccountNo;
            this.email = email;
        }
        public void deposit()
        {
            Console.WriteLine("Enter the Name");
            string n = Console.ReadLine();
            Console.WriteLine("Enter the AcountNo");
            int Acc = Convert.ToInt32(Console.ReadLine());
            if (n == name && Acc == AccountNo)
            {
                Console.WriteLine("Enter the amount to deposit");
                double d = Convert.ToDouble(Console.ReadLine());
                float Amountdeposit = (float)d;
                if (Amountdeposit > 0.0)
                    balance = balance + Amountdeposit;
                Console.WriteLine("your balance is: " + balance);
            }
            else
            {
                Console.WriteLine("please enter the name and account correctly");
            }
        }
        public void withdraw()
        {
            Console.WriteLine("Enter the Name");
            string n = Console.ReadLine();
            Console.WriteLine("Enter the AcountNo");
            int Acc = Convert.ToInt32(Console.ReadLine());
            if (n == name && Acc == AccountNo)
            {
                Console.WriteLine("Enter the withdraw amount:");
                double d = Convert.ToDouble(Console.ReadLine());
                int Amountwithdraw = (int)d;
                if (balance >= 00 && balance > Amountwithdraw)
                {
                    balance = balance - Amountwithdraw;
                }
                else
                {
                    Console.WriteLine("your balance is low");
                }
                Console.WriteLine("your balance is: " + balance);
            }
            else
            {
                Console.WriteLine("please enter the name and account correctly");
            }
        } 
        public void getbalance()
        {
            Console.WriteLine("Enter the Name");
            string n = Console.ReadLine();
            Console.WriteLine("Enter the AcountNo");
            int Acc = Convert.ToInt32(Console.ReadLine());
            if (n == name && Acc == AccountNo)
            {
                Console.WriteLine(balance);
            }
            else
            {
                Console.WriteLine("please enter the name and account correctly");
            }
        }
    }
}

*/


/*
        using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace BasicCSharp
    {
        internal class Accounts
        {
            public string acc_no;
            public string acc_name;
            public string acc_email;
            public long acc_mob;
            public long acc_bal;
            public Accounts(string acc_no, string acc_name, string acc_email, long acc_mob,
                            long acc_bal = 0)
            {
                this.acc_no = acc_no;
                this.acc_name = acc_name;
                this.acc_email = acc_email;
                this.acc_mob = acc_mob;
                this.acc_bal = acc_bal;
            }
            public void welcome()
            {
                Console.WriteLine("==============WELCOME TO THE HDFC BANK======================\n");
                Console.WriteLine("===============CHOOSE ANY ONE===============================\n");
                Console.WriteLine("1:Account Balance");
                Console.WriteLine("2:Account Deposit");
                Console.WriteLine("3:Account Withdrawl");
                Console.WriteLine("=======================================================");
                Console.Write("Choose any one:");
                int option = Convert.ToInt32(Console.ReadLine());
                //Console.WriteLine("\nYou Choose this: "+option);
                Console.WriteLine("=======================================================");
                switch (option)
                {
                    case 1:
                        void amt_bal()
                        {
                            balanceCheck();
                        }
                        amt_bal();
                        welcome();
                        break;

                    case 2:
                        void amt_depo()
                        {
                            balanceCheck();
                            Console.Write("Enter the Amount to be deposited: ");
                            long depo = Convert.ToInt64(Console.ReadLine());
                            Console.WriteLine("=======================================================");
                            Console.WriteLine("The Amount deposited is : " + depo);
                            Console.WriteLine("=======================================================");
                            long amtres = this.acc_bal + depo;
                            this.acc_bal = amtres;
                            Console.WriteLine("Your Current Balance is : " + this.acc_bal);
                        }
                        amt_depo();
                        break;

                    case 3:
                        void amt_with()
                        {
                            balanceCheck();
                            Console.Write("Enter the Amount to be withdrawed: ");
                            long wito = Convert.ToInt64(Console.ReadLine());
                            Console.WriteLine("=======================================================");
                            Console.WriteLine("The Amount withdrawed is : " + wito);
                            Console.WriteLine("=======================================================");
                            long witres = this.acc_bal - wito;
                            this.acc_bal = witres;
                            Console.WriteLine("Your Current Balance is : " + this.acc_bal);
                        }
                        amt_with();
                        break;

                    default:
                        Console.WriteLine("Please Choose Number Again");
                        welcome();
                        break;
                }
            }

            private void balanceCheck()
            {
                Console.WriteLine("Your Current Balance is :" + this.acc_bal + "\n");
            }
        }
    }

}
}
*/
