﻿namespace Calculator
{
    public class Class1
    {

       public int add(int n1,int n2)
        {
            return n1 + n2;
        }
        public int multiply(int n1,int n2)
        {
            return n1 * n2;
        }
    }

    public class ElectrictyBill
    {
        public int billamount;
        public  double calculate(int units)
        {
            //int result = 0;
            //Console.WriteLine("The Units passed to the argument here is: "+units);
            if (units <= 100)
            {
                billamount = units * 1;
            }
            else if (units >= 100 && units <= 200)
            {
                billamount = (100*1)+(units-100) * 2;
            }
            else if (units >= 200 && units <= 300)
            {
                billamount = (100 * 1) + (100 * 2)+ (units - 200) * 3;
            }
            else if (units > 300)
            {
                billamount = (100 * 1) + (100 * 2) + (100 * 3) + (units - 200) * 5;
            }
            else
            {
                Console.WriteLine("Please Enter the units");
            }
            return billamount;
        }
    }
}