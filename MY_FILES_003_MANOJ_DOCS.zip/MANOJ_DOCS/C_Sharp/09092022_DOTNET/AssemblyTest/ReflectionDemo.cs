﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace AssemblyTest
{
    internal class ReflectionDemo
    { 
        public void DisplayTest()
            {
                Assembly executing = Assembly.GetExecutingAssembly();
                Type[] types = executing.GetTypes();
                foreach (var item in types)
                {
                    Console.WriteLine("Class : {0}", item.Name);

                    MethodInfo[] methods = item.GetMethods();
                    foreach (var method in methods)
                    {
                        Console.WriteLine("--> Method : {0}", method.Name);

                        ParameterInfo[] parameters = method.GetParameters();
                        foreach (var arg in parameters)
                        {
                            Console.WriteLine("----> Parameter : {0} Type : {1}",
                                                arg.Name, arg.ParameterType);
                        }
                    }
                }
            }
        }
}
