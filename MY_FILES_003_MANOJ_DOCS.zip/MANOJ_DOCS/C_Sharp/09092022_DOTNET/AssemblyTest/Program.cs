﻿using AssemblyTest;
using Calculator;
internal class Program
{
    public static void Main(string[] args)
    {
        //Console.WriteLine("Hello, World!");

        /*
        Class1 cal = new Class1();
        cal.add(5, 2);
        */


        
        ElectrictyBill eb=new ElectrictyBill();

        Console.WriteLine("Enter The Units:");
        int units = Convert.ToInt32(Console.ReadLine());

        eb.calculate(units);

        Console.WriteLine("The Units is: " + eb.billamount);
        
        
        ReflectionDemo rd = new ReflectionDemo();
        rd.DisplayTest();
    }
}