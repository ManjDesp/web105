﻿using System;
using System.Reflection;

namespace Reflection_Demo
{
    //--------------------------REFLECTION DEMO 01----------------------------
    /*
    internal class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }    

        public Student()
        {
            RollNo = 0;
            Name=string.Empty;
        }
        public Student(int rno,string n)
        {
            RollNo = rno;
            Name = n;
        }
        public void DisplayData()
        {
            Console.WriteLine("Roll Number : {0}", RollNo);
		    Console.WriteLine("Name : {0}", Name);
        }
    }

    internal class CFG
    {
        public void DisplayTest()
        {
            Assembly executing = Assembly.GetExecutingAssembly();
            Type[] types = executing.GetTypes();
            foreach(var item in types)
            {
                Console.WriteLine("Class : {0}", item.Name);

                MethodInfo[] methods = item.GetMethods();
                foreach(var method in methods)
                {
                    Console.WriteLine("--> Method : {0}", method.Name);

                    ParameterInfo[] parameters=method.GetParameters();
                    foreach(var arg in parameters)
                    {
                        Console.WriteLine("----> Parameter : {0} Type : {1}",
											arg.Name, arg.ParameterType);
                    }
                }
            }
        }
    }
    */
    //--------------------------REFLECTION DEMO 01----------------------------
    internal class Program
    {
        public static void Main(string[] args)
        {
             // Reflection1.ReflectionDemo();

            /*
            int i=42;
            Type type=i.GetType();
            Console.WriteLine(type);
            */

            /*
            Type t =typeof(string);
            Console.WriteLine("Name : {0}",t.Name);
            Console.WriteLine("Full Name: {0}",t.FullName);
            Console.WriteLine("Namespace: {0}",t.Namespace);
            Console.WriteLine("Base Type: {0}",t.BaseType);
            */

            //--------------------------REFLECTION DEMO 01----------------------------
            /*
            CFG cfg = new CFG();
            cfg.DisplayTest();
            */
            //--------------------------REFLECTION DEMO 01----------------------------

            // Using Reflection to get information of an Assembly:
            Assembly info =typeof(int).Assembly;
            Console.WriteLine(info);
        }
    }
}

