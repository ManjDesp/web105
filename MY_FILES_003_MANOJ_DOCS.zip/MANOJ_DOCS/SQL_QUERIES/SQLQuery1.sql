create table support
(
supportid	 int			not null	primary key,
name		 varchar(100)	not null ,
issuedate	 date			not null,
description  varchar(200)	not null,
status		 char(1)		not null,
email		 varchar(100)   not null,
mobile		 bigint			not null
);


insert into support values(101,'Manoj','2016-06-19','Laptop Internet Not Working','P','md002@gmail.com',8217081616);

insert into support values(102,'Manish','2016-06-29','Laptop  Not Working','P','man002@gmail.com',7217081616);

insert into support values(103,'Nojma','2017-06-20','Data Analysis','C','n002@gmail.com',82170855123);



select * from support;