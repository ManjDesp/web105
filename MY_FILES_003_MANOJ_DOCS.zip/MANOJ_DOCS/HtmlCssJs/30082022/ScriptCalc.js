function showresult(choice) {
	var n1 = parseFloat(document.getElementById('num1').value);
	var n2 = parseFloat(document.getElementById('num2').value);
	var r;
	var c = choice;

	switch (c) {
		case 'Addition':
			r = n1 + n2;
			break;
		case 'Subtraction':
			r = n1 - n2;
			break;
		case 'Multiplication':
			r = n1 * n2;
			break;
		case 'Division':
			r = n1 / n2;
			break;
		default:
			break;

	}
	document.getElementById('result').value = r;
}
function clearScreen() {

	document.getElementById('result').value = ''
	document.getElementById('num1').value=''
	document.getElementById('num2').value=''
}
